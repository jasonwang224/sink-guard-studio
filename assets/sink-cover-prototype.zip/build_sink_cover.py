"""Parametric sink-cover prototype. Run inside Blender or through its connection bridge.
Dimensions are millimetres; editable defaults live in sink_cover_parameters.json.
Exports a Blender source, GLB, millimetre STL master and a small mesh test coupon.
"""
import bpy, bmesh, math, json, struct, runpy, re
import numpy as np
from xml.etree import ElementTree
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd()
PARAM_FILE = ROOT / 'sink_cover_parameters.json'
P = json.loads(PARAM_FILE.read_text())
MM = 0.001
W, D = P['width_mm'], P['depth_mm']
B, R = P['frame_width_mm'], P['corner_radius_mm']
N = P['faucet_notch_radius_mm']
T, WEB, GAP = P['mesh_thickness_mm'], P['web_width_mm'], P['opening_across_flats_mm']
ROOT.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.length_unit = 'MILLIMETERS'
scene.unit_settings.scale_length = 1.0

def material(name, color, roughness=.4):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Roughness'].default_value = roughness
    return m
plastic = material('Graphite PETG', (.089,.084,.101), .32)

def read_stone_profile():
    path = ElementTree.parse(ROOT / P['opening_profile']).getroot().find('{*}path')
    raw = [(float(x), -float(y)) for x, y in re.findall(r'[ML](-?[\d.]+),(-?[\d.]+)',path.attrib['d'])]
    assert len(raw) > 450
    xs, ys = zip(*raw)
    cx, cy = (min(xs)+max(xs))/2, (min(ys)+max(ys))/2
    points = [Vector((x-cx, y-cy)) for x,y in raw]
    area2 = sum(a.cross(b) for a,b in zip(points,points[1:]+points[:1]))
    return points if area2 > 0 else points[::-1]

stone_points = read_stone_profile() if P.get('opening_profile') else []

def parallel_profile(inset):
    # Offset each straight segment by the same normal distance. Intersect the
    # neighboring offset segments at their common vertex to preserve the trace.
    result = []
    for i, point in enumerate(stone_points):
        before = (point-stone_points[i-1]).normalized()
        after = (stone_points[(i+1)%len(stone_points)]-point).normalized()
        normal = Vector((-before.y-after.y, before.x+after.x))
        shifted = point + normal * (inset / (1+before.dot(after)))
        result.append(tuple(shifted))
    return result

def outline(w, d, radius, notch=0, inset=0):
    if stone_points and w == W and d == D:
        return parallel_profile(P['cover_edge_clearance_mm'] + inset)
    x, y, r = w/2-inset, d/2-inset, max(1, radius-inset)
    pts=[]
    for cx,cy,a in [(x-r,-y+r,-90),(x-r,y-r,0)]:
        pts += [(cx+r*math.cos(math.radians(a+i*90/12)),cy+r*math.sin(math.radians(a+i*90/12))) for i in range(13)]
    if notch:
        nr=notch+inset
        stem=P.get('faucet_notch_straight_mm',0)
        a=math.asin(min(0,(stem-inset)/nr))
        shoulder=P['notch_shoulder_radius_mm']
        sr=max(.01,shoulder-inset)
        cx, cy=nr+sr,y-sr
        for i in range(13):
            t=math.pi/2+math.pi*i/24
            pts.append((cx+sr*math.cos(t),cy+sr*math.sin(t)))
        pts += [(nr*math.cos(a+(-math.pi-2*a)*i/48), d/2-stem+nr*math.sin(a+(-math.pi-2*a)*i/48)) for i in range(49)]
        for i in range(13):
            t=math.pi*i/24
            pts.append((-cx+sr*math.cos(t),cy+sr*math.sin(t)))
    for cx,cy,a in [(-x+r,y-r,90),(-x+r,-y+r,180)]:
        pts += [(cx+r*math.cos(math.radians(a+i*90/12)),cy+r*math.sin(math.radians(a+i*90/12))) for i in range(13)]
    return pts

def in_rounded(x,y,w,d,r,inset):
    hx,hy=w/2-inset,d/2-inset
    rr=max(1,r-inset)
    if abs(x)>hx or abs(y)>hy: return False
    dx,dy=max(abs(x)-(hx-rr),0),max(abs(y)-(hy-rr),0)
    return dx*dx+dy*dy <= rr*rr+1e-6

def curve_solid(name, loops, zlo, zhi):
    c=bpy.data.curves.new(name,'CURVE'); c.dimensions='2D'; c.fill_mode='BOTH'; c.resolution_u=1
    c.extrude=(zhi-zlo)*MM/2
    for pts in loops:
        s=c.splines.new('POLY'); s.points.add(len(pts)-1)
        for v,(x,y) in zip(s.points,pts): v.co=(x*MM,y*MM,0,1)
        s.use_cyclic_u=True
    o=bpy.data.objects.new(name,c); scene.collection.objects.link(o); o.location.z=(zhi+zlo)*MM/2
    bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active=o
    bpy.ops.object.convert(target='MESH')
    bpy.ops.object.transform_apply(location=True, rotation=False, scale=True)
    bm=bmesh.new(); bm.from_mesh(o.data)
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-8)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces)); bm.to_mesh(o.data); bm.free()
    return o

def holes(w,d,r,border,notch=0,unclipped=False):
    result=[]; stepR=(GAP+WEB)/math.sqrt(3); holeR=GAP/math.sqrt(3)
    for col in range(-int(w/(1.5*stepR)),int(w/(1.5*stepR))+1):
        x=col*1.5*stepR
        for row in range(-int(d/(math.sqrt(3)*stepR)),int(d/(math.sqrt(3)*stepR))+1):
            y=(row+.5*(col%2))*math.sqrt(3)*stepR
            pts=[(x+holeR*math.cos(i*math.pi/3),y+holeR*math.sin(i*math.pi/3)) for i in range(6)]
            if unclipped:
                if abs(x)>w/2+holeR or abs(y)>d/2+holeR: continue
            else:
                if not all(in_rounded(a,b,w,d,r,border) for a,b in pts): continue
                if notch and any(a*a+(b-d/2)**2 < (notch+border)**2 for a,b in pts): continue
            result.append(list(reversed(pts)))
    return result

def clean_mesh(o):
    # Remove sub-micron boolean/bevel remnants before float32 STL/GLB export.
    bm=bmesh.new();bm.from_mesh(o.data)
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7)
    bmesh.ops.dissolve_degenerate(bm,dist=1e-7,edges=list(bm.edges))
    bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='BEAUTY')
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7)
    bmesh.ops.dissolve_degenerate(bm,dist=1e-7,edges=list(bm.edges))
    bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method='BEAUTY',ngon_method='BEAUTY')
    wire_edges=[e for e in bm.edges if not e.link_faces]
    if wire_edges:bmesh.ops.delete(bm,geom=wire_edges,context='EDGES')
    loose_verts=[v for v in bm.verts if not v.link_edges]
    if loose_verts:bmesh.ops.delete(bm,geom=loose_verts,context='VERTS')
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(o.data);bm.free();o.data.update()

def boolean(target,other,operation):
    bpy.context.view_layer.objects.active=target
    mod=target.modifiers.new(operation,'BOOLEAN');mod.operation=operation;mod.solver='MANIFOLD';mod.object=other
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(other,do_unlink=True)

def lattice(name,w,d,r,border,notch=0,base=0):
    body=curve_solid(name,[outline(w,d,r,notch)],base,base+T)
    allhex=holes(w,d,r,border,notch,True)
    # Intersect the voids with the frame interior. Partial cells reach the rim,
    # avoiding the wide scalloped solid margins left by rejecting edge cells.
    cutters=curve_solid('Hexagonal voids',allhex,base-1,base+T+1)
    limit=curve_solid('Inner frame boundary',[outline(w,d,r,notch,border)],base-2,base+T+2)
    boolean(cutters,limit,'INTERSECT')
    boolean(body,cutters,'DIFFERENCE')
    return body

cover=lattice('Sink Guard | flush honeycomb',W,D,R,B,N,base=P['frame_rise_mm'])
cover.data.materials.append(plastic)
frame=curve_solid('Slim perimeter frame',[outline(W,D,R,N),list(reversed(outline(W,D,R,N,B)))],-P['frame_drop_mm'],T+P['frame_rise_mm'])

# The underside return is integral to the printable cover and follows the faucet relief.
seat_z = T + P['frame_rise_mm'] - P['counter_to_shelf_mm']
outer_inset = P['support_inset_mm']
inner_inset = outer_inset + P['support_wall_mm']
assert inner_inset < min(B,P['shelf_overlap_mm']) and seat_z <= -P['frame_drop_mm']
if seat_z < -P['frame_drop_mm']:
    support = curve_solid('Integral support rim', [
        outline(W,D,R,N,outer_inset),
        list(reversed(outline(W,D,R,N,inner_inset)))],seat_z,0.25)
    boolean(frame,support,'UNION')
boolean(cover,frame,'UNION')
clean_mesh(cover)

bevel=cover.modifiers.new('Soft edges 0.35 mm','BEVEL'); bevel.width=.35*MM; bevel.segments=2
bpy.context.view_layer.objects.active=cover
bpy.ops.object.modifier_apply(modifier=bevel.name)
clean_mesh(cover)
cover.data.materials.clear();cover.data.materials.append(plastic)
for p in cover.data.polygons: p.use_smooth=False;p.material_index=0

def mesh_report(o):
    bm=bmesh.new(); bm.from_mesh(o.data)
    bad=sum(not e.is_manifold for e in bm.edges)
    boundary=sum(e.is_boundary for e in bm.edges)
    volume=bm.calc_volume(signed=True)/MM**3
    unvisited=set(bm.verts); components=0
    while unvisited:
        components+=1; stack=[unvisited.pop()]
        while stack:
            v=stack.pop()
            for e in v.link_edges:
                other=e.other_vert(v)
                if other in unvisited: unvisited.remove(other); stack.append(other)
    o.data.calc_loop_triangles()
    xyz = np.array([tuple(v.co) for v in o.data.vertices], dtype=np.float64)
    triangles = xyz[np.array([tuple(t.vertices) for t in o.data.loop_triangles])]
    normals = np.cross(triangles[:,1]-triangles[:,0], triangles[:,2]-triangles[:,0])
    collapsed = int(np.count_nonzero(np.all(normals == 0, axis=1)))
    result={'vertices':len(bm.verts),'faces':len(bm.faces),'non_manifold_edges':bad,'boundary_edges':boundary,'zero_area_faces':collapsed,'connected_components':components,'volume_mm3':round(volume,2),'dimensions_mm':[round(v/MM,3) for v in o.dimensions]}
    bm.free(); return result

def stl(o,path):
    mesh=o.data; mesh.calc_loop_triangles()
    with path.open('wb') as f:
        f.write(b'Sink Guard prototype; coordinates in millimetres'.ljust(80,b'\0'))
        f.write(struct.pack('<I',len(mesh.loop_triangles)))
        for tri in mesh.loop_triangles:
            vs=[o.matrix_world @ mesh.vertices[i].co for i in tri.vertices]
            n=(vs[1]-vs[0]).cross(vs[2]-vs[0]).normalized()
            f.write(struct.pack('<12fH',*n,*[c/MM for v in vs for c in v],0))

bpy.context.view_layer.update()
report={'parameters':P,'master':mesh_report(cover),'status':'Paper-checked stone outline. Installed height uses the measured steel shelf drop. Flat bearing width and load capacity require physical checks.'}
assert report['master']['non_manifold_edges']==0, report
assert report['master']['connected_components']==1, report
assert report['master']['zero_area_faces']==0, report
stl(cover,ROOT/'sink-cover-master-mm.stl')
bpy.ops.object.select_all(action='DESELECT')
cover.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(ROOT/'sink-cover.glb'),export_format='GLB',use_selection=True,export_apply=True)

coupon=lattice('80 mm test coupon',80,80,12,6)
coupon.data.materials.clear();coupon.data.materials.append(plastic)
mod=coupon.modifiers.new('Soft edges','BEVEL');mod.width=.35*MM;mod.segments=2
bpy.context.view_layer.objects.active=coupon;bpy.ops.object.modifier_apply(modifier=mod.name)
clean_mesh(coupon)
report['coupon']=mesh_report(coupon)
assert report['coupon']['non_manifold_edges']==0
stl(coupon,ROOT/'mesh-test-coupon-80mm.stl')
bpy.data.objects.remove(coupon,do_unlink=True)

cover['prototype_status']=report['status']
cover['dimensions_mm']=f'{W} x {D}'
text=bpy.data.texts.new('Parameters and prototype notes');text.write(json.dumps(report,indent=2))
script=bpy.data.texts.new('build_sink_cover.py');script.write((ROOT/'build_sink_cover.py').read_text())

def aim(o,point): o.rotation_euler=(Vector(point)-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(-.2382,-1.2398,.81172));cam=bpy.context.object;cam.name='Product camera';cam.data.type='PERSP';cam.data.lens=58;aim(cam,(.01967,.00544,.01486));scene.camera=cam
cam.data.clip_start=.001
for loc,power,size,color in [
    ((-.48,-.36,.88),33,.54,(1,.86,.73)),
    ((.70,-.16,.50),5,.38,(.82,.89,1)),
    ((.14,.35,.67),14,.36,(1,.87,.74))
]:
    bpy.ops.object.light_add(type='AREA',location=loc)
    light=bpy.context.object
    light.data.energy=power
    light.data.color=color
    light.data.shape='DISK'
    light.data.size=size
    aim(light,(0,0,0))
scene.world.use_nodes=True
bg=scene.world.node_tree.nodes.get('Background')
bg.inputs['Color'].default_value=(.34,.29,.24,1)
bg.inputs['Strength'].default_value=.14
scene.render.engine='CYCLES';scene.cycles.samples=24
scene.render.resolution_x=1440;scene.render.resolution_y=850;scene.render.resolution_percentage=100
scene.render.film_transparent=False
scene.view_settings.view_transform='AgX'
scene.view_settings.look='AgX - Medium High Contrast'
scene.view_settings.exposure=-.68
bpy.ops.object.select_all(action='DESELECT');cover.select_set(True);bpy.context.view_layer.objects.active=cover
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_distance=1.1
            area.spaces.active.region_3d.view_location=(0,0,0)
            area.spaces.active.clip_end=100
display_script=ROOT/'build_display_scene.py'
runpy.run_path(str(display_script))['build_display_scene'](ROOT,outline,curve_solid,W,D,R,N,P)
scene.cycles.use_denoising=True
scene.cycles.samples=32
bpy.ops.object.select_all(action='DESELECT')
cover.select_set(True);bpy.context.view_layer.objects.active=cover
for area in bpy.context.screen.areas:
    if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
for name in ('Parameters and prototype notes','build_sink_cover.py','build_display_scene.py'):
    for block in list(bpy.data.texts):
        if block.name==name or block.name.startswith(name+'.'):bpy.data.texts.remove(block)
for name in ('build_sink_cover.py','build_display_scene.py'):
    bpy.data.texts.new(name).write((ROOT/name).read_text())
bpy.data.texts.new('Parameters and prototype notes').write(json.dumps(report,indent=2))
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'sink-cover-prototype.blend'))
(ROOT/'model-validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2),flush=True)
