"""Build the illustrative sink scene for the reference camera and optional viewer context.

Run from build_sink_cover.py, after the printable model has been exported.
"""
import bpy
import math
import numpy as np
from mathutils import Vector


def build_display_scene(root, outline, curve_solid, width, depth, radius, notch, params):
    scene = bpy.context.scene
    collection = bpy.data.collections.new("Display only | kitchen")
    scene.collection.children.link(collection)

    def finish(obj, name, mat):
        obj.name = name
        obj.data.materials.clear()
        obj.data.materials.append(mat)
        for group in list(obj.users_collection):
            group.objects.unlink(obj)
        collection.objects.link(obj)
        return obj

    def surface(name, rgb, metal=0, rough=.4):
        mat = bpy.data.materials.new(name)
        mat.diffuse_color = (*rgb, 1)
        mat.use_nodes = True
        shader = mat.node_tree.nodes.get("Principled BSDF")
        shader.inputs["Base Color"].default_value = (*rgb, 1)
        shader.inputs["Metallic"].default_value = metal
        shader.inputs["Roughness"].default_value = rough
        return mat

    stone = surface("Honed marble", (.49,.34,.22), rough=.43)
    steel = surface("Brushed stainless", (.48,.47,.45), .91, .26)
    basin_steel = surface("Basin stainless", (.31,.29,.27), .93, .32)
    nickel = surface("Warm brushed nickel", (.60,.56,.50), .95, .20)
    ceramic = surface("Taupe glazed stoneware", (.255,.215,.171), rough=.26)
    dark = surface("Drain perforations", (.025,.028,.025), .35, .5)
    grout = surface("Warm porcelain backsplash", (.40,.32,.25), rough=.55)

    # Packed seamless stone texture, shared by the Cycles camera and web scene.
    rng = np.random.default_rng(322)
    size = 768
    xx, yy = np.meshgrid(np.arange(size)/size,np.arange(size)/size)
    def field(n):
        grid = rng.normal(size=(n,n))
        u,v = xx*n, yy*n
        i,j = u.astype(int),v.astype(int)
        a,b = u-i,v-j
        a,b = a*a*(3-2*a),b*b*(3-2*b)
        return ((1-b)*((1-a)*grid[j%n,i%n]+a*grid[j%n,(i+1)%n])
                +b*((1-a)*grid[(j+1)%n,i%n]+a*grid[(j+1)%n,(i+1)%n]))
    grain = field(11)*.044 + field(31)*.030 + field(73)*.023 + field(249)*.018
    mineral = field(7) + .30*field(30) + .12*field(89)
    vein = np.exp(-np.abs(mineral)*12)*.115
    pores = np.maximum(field(249)-.78,0)*.078
    rgb = np.array([.73,.605,.495])+ (grain-vein-pores)[:,:,None]
    rgba = np.ones((size,size,4),dtype=np.float32)
    rgba[:,:,:3] = np.clip(rgb,0,1)
    im = bpy.data.images.new("Warm marble grain",size,size,alpha=False)
    im.pixels.foreach_set(rgba.ravel())
    im.pack()
    tex = stone.node_tree.nodes.new("ShaderNodeTexImage")
    tex.image = im
    stone.node_tree.links.new(tex.outputs["Color"],stone.node_tree.nodes.get("Principled BSDF").inputs["Base Color"])

    def bevel(obj, amount):
        bpy.context.view_layer.objects.active=obj
        mod=obj.modifiers.new("Edge radius","BEVEL")
        mod.width=amount; mod.segments=4
        bpy.ops.object.modifier_apply(modifier=mod.name)

    def box(name, location, dims, mat, fillet):
        bpy.ops.mesh.primitive_cube_add(size=1,location=location)
        obj=bpy.context.object
        obj.dimensions=dims
        bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        bevel(obj,fillet)
        return finish(obj,name,mat)

    def round_object(name, profile, mat, xy=(0,0), smooth=True):
        vertices=[]; faces=[]; count=96
        for r,z in profile:
            for i in range(count):
                a=i*2*math.pi/count
                vertices.append((xy[0]+r*math.cos(a),xy[1]+r*math.sin(a),z))
        for k in range(len(profile)-1):
            for i in range(count):
                j=(i+1)%count
                faces.append((k*count+i,k*count+j,(k+1)*count+j,(k+1)*count+i))
        faces.append(tuple(reversed(range(count))))
        faces.append(tuple(range(len(vertices)-count,len(vertices))))
        mesh=bpy.data.meshes.new(name);mesh.from_pydata(vertices,[],faces);mesh.update()
        obj=bpy.data.objects.new(name,mesh);collection.objects.link(obj);mesh.materials.append(mat)
        for poly in list(mesh.polygons)[:-2]: poly.use_smooth=smooth
        return obj

    def tube(name, points, radius_m, mat):
        curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D'
        curve.bevel_depth=radius_m;curve.bevel_resolution=6;curve.use_fill_caps=True
        spline=curve.splines.new('POLY');spline.points.add(len(points)-1)
        for p,xyz in zip(spline.points,points):p.co=(*xyz,1)
        obj=bpy.data.objects.new(name,curve);collection.objects.link(obj);curve.materials.append(mat)
        bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
        bpy.ops.object.convert(target='MESH')
        for poly in obj.data.polygons: poly.use_smooth=True
        return obj

    # Width and depth refer to the removable cover. All scenery is illustrative.
    surface_z = params['mesh_thickness_mm'] + params['frame_rise_mm']
    bearing_z = surface_z - params['counter_to_shelf_mm']
    clearance = params['cover_edge_clearance_mm']
    overlap = params['shelf_overlap_mm']
    opening = outline(width,depth,radius,notch,inset=-clearance)
    outer = [(-1450,-300),(1450,-300),(1450,467),(-1450,467)]
    top = curve_solid("Marble countertop",[outer,list(reversed(opening))],bearing_z,surface_z)
    bevel(top,.0006)
    finish(top,"Marble countertop",stone)
    uv = top.data.uv_layers.new(name='Stone coordinates')
    top.data.uv_layers.active=uv
    uv.active_render=True
    for poly in top.data.polygons:
        for li in poly.loop_indices:
            point=top.data.vertices[top.data.loops[li].vertex_index].co
            uv.data[li].uv=((point.x+point.z)*1.9,(point.y+point.z)*1.9)
    basin_boundary = outline(width,depth,radius,notch,inset=overlap)
    flange_outer=outline(width,depth,radius,notch,inset=-clearance-8)
    rim=curve_solid("Stainless support shelf",[flange_outer,list(reversed(basin_boundary))],bearing_z-1.2,bearing_z)
    finish(rim,"Stainless support shelf",steel)
    rings=[(1,1,bearing_z),(.994,.991,bearing_z-3.5),(.988,.984,bearing_z-8.5),(.972,.956,-122),(.954,.935,-148),(.92,.895,-161),(.865,.835,-167)]
    vertices=[]; faces=[]; n=len(basin_boundary)
    for sx,sy,z in rings:
        vertices.extend((x*sx*.001,y*sy*.001,z*.001) for x,y in basin_boundary)
    for k in range(len(rings)-1):
        for i in range(n):
            j=(i+1)%n
            faces.append((k*n+i,k*n+j,(k+1)*n+j,(k+1)*n+i))
    faces.append(tuple(range(len(vertices)-n,len(vertices))))
    mesh=bpy.data.meshes.new("Pressed basin");mesh.from_pydata(vertices,[],faces);mesh.update()
    basin=bpy.data.objects.new("Pressed basin",mesh);collection.objects.link(basin);mesh.materials.append(basin_steel)
    for poly in list(mesh.polygons)[:-1]:poly.use_smooth=True
    for x,y,z,r in [(-.115,-.032,-.164,.108),(-.115,-.033,-.157,.10),(.118,.015,-.164,.081)]:
        round_object("Stoneware under cover",[(.043,z),(.067,z+.002),(r,z+.018),(r+.001,z+.021),(r-.003,z+.022),(.063,z+.009),(.04,z+.008)],ceramic,(x,y))
    round_object("Drain flange",[(.045,-.167),(.045,-.164),(.032,-.163),(.027,-.165)],steel,(.045,.10))
    for i in range(12):
        a=i*math.pi/6
        round_object("Drain slot",[(.002,-.1648),(.002,-.1644)],dark,(.045+.019*math.cos(a),.10+.019*math.sin(a)))
    # The real faucet is mounted in the stone behind the left shoulder.
    fy = depth*.0005+.030
    before_faucet = set(collection.objects)
    round_object("Mixer mounting collar",[(.031,-.002),(.0315,.002),(.030,.004),(.026,.006)],nickel,(0,fy))
    round_object("Mixer barrel",[(.025,.004),(.025,.010),(.023,.012),(.020,.110),(.018,.115),(.016,.141)],nickel,(0,fy))
    arch=[(0,fy,.109),(0,fy,.20)]
    for i in range(65):
        a=i*math.pi/64
        arch.append((.018*(1-math.cos(a)),fy-.065*(1-math.cos(a)),.201+.076*math.sin(a)))
    arch.append((.036,fy-.130,.181))
    tube("Curved faucet neck",arch,.012,nickel)
    round_object("Pull-down spout",[(.017,.143),(.0175,.146),(.014,.182),(.012,.187)],nickel,(.036,fy-.13))
    round_object("Aerator",[(.012,.142),(.012,.1435)],dark,(.036,fy-.13))
    tube("Handle stem",[(.012,fy,.068),(.045,fy,.072)],.010,nickel)
    tube("Mixer lever",[(.044,fy,.067),(.048,fy,.126)],.006,nickel)
    for obj in set(collection.objects)-before_faucet:
        obj.location.x -= .195
        obj.location.z += (surface_z+2)*.001
    box("Backsplash",(0,.448,.17),(2.9,.018,.40),grout,.002)
    # Independent context GLB. Printable files contain cover geometry only.
    bpy.ops.object.select_all(action='DESELECT')
    for obj in collection.objects:obj.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(root/'sink-setting.glb'),export_format='GLB',use_selection=True,export_apply=True)
    return collection
